export function openLink(value: string) {
  window.open(value, "_blank", "noopener,noreferrer");
  return null;
}
